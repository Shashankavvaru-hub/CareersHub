export const moduleName = 'media';
