export const moduleName = 'media';
