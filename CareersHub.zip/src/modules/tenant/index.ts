export const moduleName = 'tenant';
