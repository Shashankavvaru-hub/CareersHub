export const moduleName = 'publishing';
