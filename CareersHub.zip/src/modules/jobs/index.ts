export const moduleName = 'jobs';
