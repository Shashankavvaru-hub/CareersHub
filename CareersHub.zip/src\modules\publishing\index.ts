export const moduleName = 'publishing';
