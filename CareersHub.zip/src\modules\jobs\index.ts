export const moduleName = 'jobs';
