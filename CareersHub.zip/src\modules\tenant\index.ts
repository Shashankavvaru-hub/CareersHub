export const moduleName = 'tenant';
